﻿

namespace AMSnake
{
    public enum GridValue
    {
        Empty,
        Snake,
        Food,
        Wall,
        Outside
    }
}
